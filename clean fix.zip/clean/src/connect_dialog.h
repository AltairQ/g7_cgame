// Mateusz Maciejewski
// 15.02.2017
// connect_dialog.h

//main thread function for connecting dialog
int connect_dialog_stageloop(g7_stage *stage);
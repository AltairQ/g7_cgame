// Mateusz Maciejewski
// 15.02.2017
// gameplay.h

//main thread
int gameplay_stageloop(g7_stage *stage);

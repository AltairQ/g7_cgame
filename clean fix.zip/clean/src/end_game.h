// Mateusz Maciejewski
// 15.02.2017
// end_game.h

int end_game_stageloop(g7_stage *stage);
// Mateusz Maciejewski
// 15.02.2017
// main_menu.h

//main menu dialog

//main thread
int main_menu_stageloop(g7_stage *stage);
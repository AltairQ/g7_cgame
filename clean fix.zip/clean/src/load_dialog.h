// Mateusz Maciejewski
// 15.02.2017
// load_dialog.h

//load save dialog

//main thread
int load_dialog_stageloop(g7_stage *stage);
